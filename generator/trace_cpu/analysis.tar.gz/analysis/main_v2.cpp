#include<iostream>
#include<fstream>
#include<stdio.h>
#include<vector>
#include<string>
#include<stdlib.h>
#include<math.h>
using namespace std;
#define PIPELINE 5
//#define INTERVAL 100000
#define NUM 64

vector < vector < int > > C;
double corr[NUM][NUM];
int ID;
struct item{
    int ID;
    double value;
};
double calc_var(vector<int> &x, vector<int> &y);
double calc_means(vector<int> &x);
bool sort_value(const item &x, const item &y);
vector <item> cSortCorr;
vector <item> cSort;

int main(int argc, char** argv){
        int iArg=1;
        double freq=0;
        int interval=0;
        //string temp_str;
        char name[100];
        do{
            if(!strcmp(argv[iArg],"-help")){
                cout<<"-n  name  -i  time_interval -f frequency"<<endl;
                cout<<"name:[benchmarkname_adp/xy]"<<endl;
                cout<<"time_interval:[100/1000/10000/100000]"<<endl;
                cout<<"frequency:[0.1/0.25/0.33/0.5/0.66/0.75/1]"<<endl;
                return 0;
            }
            else if(!strcmp(argv[iArg],"-n")){
                strcpy(name,argv[iArg+1]);
                iArg+=2;
                cout<<name<<endl;
            }
            else if(!strcmp(argv[iArg],"-i")){
                interval=atoi(argv[iArg+1]);
                iArg+=2;
            }
            else if(!strcmp(argv[iArg],"-f")){
                freq=atof(argv[iArg+1]);
                iArg+=2;
            }
        }
        while(iArg<argc);


        int id;
        long int total_cycle;
        long int cycle;
        string pipeline;
        char lastLine[100];

        fstream fin;
        strcpy(lastLine,"./last_line/last_line_");
        strcat(lastLine,name);
        strcat(lastLine,".txt");
        fin.open(lastLine);
        fin>>id>>pipeline>>total_cycle;
        fin.close();
        fin.clear();
        cout<<"initialization finished"<<endl;


        fstream fin2;
        C.resize(NUM);
        for(int i=0;i<NUM;i++){
            C[i].resize(total_cycle/interval+1);
        }
        char srcFile[100];
        strcpy(srcFile,"../cpu_");
        strcat(srcFile,name);
        strcat(srcFile,".txt");
        fin2.open(srcFile);
        fin2>>id>>pipeline>>cycle;
        while(!fin2.eof()){
                if(pipeline=="dispatch"){
                    C[id][cycle/interval]++;
                   // cout<<"id:"<<id<<"     time point:"<<cycle/interval<<endl;
                }
                fin2>>id>>pipeline>>cycle;
        }
        fin2.close();
        cout<<"Time series calculate"<<endl;

        char timeSeries[100];
        strcpy(timeSeries,"./output/");
        strcat(timeSeries,name);
        strcat(timeSeries,"_TS.txt");
        ofstream TS;
        TS.open(timeSeries);
        for(int i=0;i<NUM;i++){
            for(int j=0;j<C[i].size();j++){
                TS<<C[i][j]<<"  ";
            }
            TS<<endl;
        }
        TS.close();
        cout<<"Time series output finished"<<endl;

        char corrSeries[100];
        strcpy(corrSeries,"./output/");
        strcat(corrSeries,name);
        strcat(corrSeries,"_corr.txt");
        double temp;
        ofstream fCorr;
        fCorr.open(corrSeries);
        for(int i=0;i<NUM;i++){
                for(int j=0;j<NUM;j++){
                    temp=calc_var(C[i],C[j]);
                    corr[i][j]=temp;//calc_var(C[i],C[j]);
                }
        }
        cout<<"calculate correlation"<<endl;

        for(int i=0;i<NUM;i++){
                for(int j=0;j<NUM;j++){
                    fCorr<<corr[i][j]<<"  ";
                }
                fCorr<<endl;
        }
        fCorr.close();
        cout<<"output correlation"<<endl;

        cSort.resize(NUM);
        cSortCorr.resize(NUM);
        for(int i=0;i<NUM;i++){
            cSort[i].ID=i;
            cSortCorr[i].ID=i;
            cSort[i].value=calc_means(C[i]);
            cSortCorr[i].value=0;
        }
        for(int i=0;i<NUM;i++){
                for(int j=0;j<NUM;j++){
                    cSortCorr[i].value+=calc_means(C[j])*corr[i][j];
                }
        }

        char uSortAi[100];
        char uSortCorr[100];
        strcpy(uSortAi,"./output/");
        strcpy(uSortCorr,"./output/");
        strcat(uSortAi,name);
        strcat(uSortCorr,name);
        strcat(uSortAi,"_usort_ai.txt");
        strcat(uSortCorr,"_usort_corr.txt");
        ofstream fC;
        ofstream fCCorr;
        fC.open(uSortAi);
        fCCorr.open(uSortCorr);
        for(int i=0;i<NUM;i++){
            fC<<cSort[i].ID<<"   "<<cSort[i].value<<endl;
            fCCorr<<cSortCorr[i].ID<<"   "<<cSortCorr[i].value<<endl;
        }
        fC.close();
        fCCorr.close();
        cout<<"output cpu statistic"<<endl;

        sort(cSort.begin(),cSort.end(),sort_value);
        sort(cSortCorr.begin(),cSortCorr.end(),sort_value);
        char sortedAi[100];
        char sortedCorr[100];
        strcpy(sortedAi,"./output/");
        strcpy(sortedCorr,"./output/");
        strcat(sortedAi,name);
        strcat(sortedCorr,name);
        strcat(sortedAi,"_sorted_Ai.txt");
        strcat(sortedCorr,"_sorted_Corr.txt");
        cout<<sortedCorr<<endl;
        ofstream fSortedAi;
        ofstream fSortedCorr;
        fSortedAi.open(sortedAi);
        fSortedCorr.open(sortedCorr);
        for(int i=0;i<NUM;i++){
            fSortedAi<<"P   "<<cSort[i].ID<<"   "<<cSort[i].value<<"    "<<freq<<endl;
            fSortedCorr<<"P "<<cSortCorr[i].ID<<"   "<<cSortCorr[i].value<<"    "<<freq<<endl;
        }
        fSortedAi.close();
        fSortedCorr.close();

       // cout<<id<<"   "<<pipeline<<"   "<<total_cycle<<endl;
        return 1;       
}

double calc_var( vector<int> &x, vector<int> &y){
        double mean_x=calc_means(x);
        double mean_y=calc_means(y);
        double var=0;
        double up_factor=0;
        double down_factor_x=0;
        double down_factor_y=0;
        for(int i=0;i<x.size();i++){
            up_factor+=(x[i]-mean_x)*(y[i]-mean_y);
            down_factor_x+=(x[i]-mean_x)*(x[i]-mean_x);
            down_factor_y+=(y[i]-mean_y)*(y[i]-mean_y);
        }
        var=up_factor/(sqrt(down_factor_x*down_factor_y));
        return var;
}
double calc_means(vector<int> &x){
        double sum;
        for(int i=0;i<x.size();i++){
            sum+=x[i];
        }
        sum/=x.size();
        return sum;
}
bool sort_value(const item &x, const item &y){
    return x.value<y.value;
}
